#!/usr/bin/env python3
"""Embed real brand photos into the Polished Pear website"""
from PIL import Image
import base64, io, re, os

os.chdir('/home/team/shared')

# --- Resize & encode logo (200x200, PNG) ---
logo = Image.open('logo.png')
logo = logo.resize((200, 200), Image.LANCZOS)
buf = io.BytesIO()
logo.save(buf, format='PNG', optimize=True)
logo_b64 = base64.b64encode(buf.getvalue()).decode()
logo_data_uri = f"data:image/png;base64,{logo_b64}"

# --- Resize & encode brand photo for hero (1200px wide, PNG) ---
photo = Image.open('brand_photo.jpg')
w = 1200
h = int(photo.size[1] * w / photo.size[0])
photo = photo.resize((w, h), Image.LANCZOS)
buf2 = io.BytesIO()
photo.save(buf2, format='PNG', optimize=True)
photo_b64 = base64.b64encode(buf2.getvalue()).decode()
photo_data_uri = f"data:image/png;base64,{photo_b64}"

# --- Read current HTML ---
with open('index.html', 'r') as f:
    html = f.read()

# 1. Replace the SVG logo in the NAV (the inline SVG between the nav-logo span)
# Find the nav-logo block
nav_logo_pattern = r'(<a href="#hero" class="nav-logo">)(.*?)(</a>)'
def replace_nav_logo(match):
    open_tag = match.group(1)
    close_tag = match.group(3)
    return f'{open_tag}<img src="{logo_data_uri}" alt="Polished Pear & Company" style="width:36px;height:36px;border-radius:6px;"><span>Polished Pear</span>{close_tag}'
html = re.sub(nav_logo_pattern, replace_nav_logo, html, count=1)

# 2. Replace the footer logo similarly
footer_logo_pattern = r'(<a href="#hero" class="nav-logo" style="color:#fff;">)(.*?)(</a>)'
def replace_footer_logo(match):
    open_tag = match.group(1)
    close_tag = match.group(3)
    return f'{open_tag}<img src="{logo_data_uri}" alt="Polished Pear & Company" style="width:32px;height:32px;border-radius:6px;"><span>Polished Pear</span>{close_tag}'
html = re.sub(footer_logo_pattern, replace_footer_logo, html, count=1)

# 3. Replace the hero background gradient/pattern with the brand photo
# Replace the hero-bg-pattern div
hero_bg_pattern = r'<div class="hero-bg-pattern"></div>'
html = html.replace(hero_bg_pattern, f'<div class="hero-bg-pattern" style="background-image:url(\'{photo_data_uri}\');background-size:cover;background-position:center;opacity:0.25;"></div>')

# 4. Replace the about section photo placeholders with the logo
about_placeholder1 = r'<div class="about-photo-placeholder">\s*<svg.*?</svg>\s*<span>Kalli & Maria</span>'
def replace_about_photo(match):
    return f'<div class="about-photo-placeholder" style="background:linear-gradient(135deg, #B5C99A, #7A9A5B);overflow:hidden;padding:0;"><img src="{logo_data_uri}" alt="Kalli & Maria" style="width:100%;height:100%;object-fit:cover;"></div>'

html = re.sub(r'<div class="about-photo-placeholder">\s*<svg[\s\S]*?</svg>\s*<span>Kalli & Maria</span>\s*<span[^>]*>Your organizing team</span>\s*</div>', replace_about_photo, html, count=1)

# --- Write updated HTML ---
with open('index.html', 'w') as f:
    f.write(html)

print("Done! Website updated with real brand photos.")
print(f"Logo data URI length: {len(logo_b64)} chars")
print(f"Photo data URI length: {len(photo_b64)} chars")