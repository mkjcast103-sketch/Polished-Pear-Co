#!/usr/bin/env python3
"""Resize images and output base64 data URIs for embedding in HTML"""
from PIL import Image
import base64, io, os

os.chdir('/home/team/shared')

# Resize logo to 200x200
img = Image.open('logo.png')
img = img.resize((200, 200), Image.LANCZOS)
buf = io.BytesIO()
img.save(buf, format='PNG', optimize=True)
logo_b64 = base64.b64encode(buf.getvalue()).decode()
print(f"LOGO_B64={logo_b64}")
print(f"LOGO_LEN={len(logo_b64)}")

# Resize brand photo for hero - 1200px wide
img2 = Image.open('brand_photo.jpg')
w_percent = 1200 / float(img2.size[0])
h_size = int(float(img2.size[1]) * w_percent)
img2 = img2.resize((1200, h_size), Image.LANCZOS)
buf2 = io.BytesIO()
img2.save(buf2, format='PNG', optimize=True)
photo_b64 = base64.b64encode(buf2.getvalue()).decode()
print(f"PHOTO_B64={photo_b64}")
print(f"PHOTO_LEN={len(photo_b64)}")