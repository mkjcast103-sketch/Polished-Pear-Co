#!/bin/bash
team-db "SELECT id, title, status, assigned_to FROM tasks WHERE id = 'a3d36a38-52df-42f4-b3a9-c8320001cfea'"
