#!/bin/bash
set -e
cd /tmp
git clone https://github.com/mkjcast103-sketch/Polished-Pear-Co.git pp-repo 2>&1
cd pp-repo
cp /home/team/shared/index.html ./index.html 2>&1
git config user.name "Polished Pear Team"
git config user.email "hello@polishedpearco.com"
git add index.html 2>&1
git commit -m "Initial website launch - Polished Pear & Co" 2>&1
git push origin main 2>&1
echo "DONE"