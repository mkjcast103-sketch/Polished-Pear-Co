# Code Workflow — Polished Pear & Company

## Branch Strategy
- `main` — production branch. Always deployable.
- Feature branches off `main` for any changes.

## PR Process
- Push to feature branches and open PRs.
- Lead reviews and merges.

## Deployment
- GitHub Pages serves from the `main` branch `/` (root).
- Any merge to `main` auto-deploys.